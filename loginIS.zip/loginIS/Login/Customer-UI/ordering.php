<?php
    require '../../includes/db.php';
    session_start();
    $qty = $_POST['qty'];
    $name = $_SESSION['name1'];
    $email = $_SESSION['email1'];
    $text = $_POST['textarea'];
    $productid = $_GET['id'];
    $catid = $_GET['cid'];
    $orders = mysqli_query($conn, "INSERT INTO orders VALUES ('?','$name','$email','0')");
    $select = mysqli_query($conn, "SELECT * FROM orders WHERE reg_name = '$name' AND reg_email = '$email' ORDER BY order_id DESC");
    $selectRS = mysqli_fetch_assoc($select);
    $orderid = $selectRS['order_id'];
    $orderlist = mysqli_query($conn, "INSERT INTO order_list VALUES ('?','$orderid','$productid','$catid','$qty','$text',CURRENT_TIMESTAMP)"); 
?>
        <script language="javascript">
        alert("Successfully ordered!");
        location.href = "menu.php";
        </script>