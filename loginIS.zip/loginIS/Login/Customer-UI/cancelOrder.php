<?php
require '../../includes/db.php';
session_start();
$name = $_SESSION['name1'];
$email = $_SESSION['email1'];
$id = $_GET['id'];
$delete = mysqli_query($conn, "DELETE FROM orders WHERE order_id = $id");
?>
<script language="javascript">
    alert("Successfully deleted!");
    location.href = "menu.php";
</script>