<?php
    require '../../includes/db.php';
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</head>
<body>
<header>
        <img id="image-hr" src="img/header.png?tr=w-1200,h-400">
    </header>
    <br><br><br><br><br><br>
    <nav id="navbar">
      <script>
        $("#exampleModal").on("shown.bs.modal", function(){
        $(this).find("input").first().focus()
        })
      </script>
    <a href="#exampleModal" data-toggle="modal" data-target="#exampleModal" class="mt-2"><img src="img/nav-img.jpg"></a>    
    
        <ul id="navcontent">     
            <li><a href="about.php">Home</a></li>
            <li><a href="about2.php">About</a></li>
            <li><a href="about.php">Menu</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="../logout.php">Logout</a></li> 
        </ul>
    </nav>
    <?php
    $add = "";
    $sort = "Sort";
    $sorting = "";
    $pastries = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
    $pastriesModal = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
    $i = 2;
    if(isset($_GET['sort'])){
      $sorting = $_GET['sort'];
    }
    if($sorting == "desc"){
      $sort = "Lowest Price";
      $add = " ORDER BY product_price";
      $pastries = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
      $pastriesModal = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
    }else if($sorting == "asc"){
      $sort = "Highest Price";
      $add = " ORDER BY product_price DESC";
      $pastries = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
      $pastriesModal = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
    }else if($sorting == "best"){
      $sort = "Best sellers";
      $pastries = mysqli_query($conn, "SELECT *,order_list.product_id, product_list.product_name AS final, product_list.product_price AS price, SUM(order_list.order_qty) AS 
                                            totalQuantity FROM order_list, product_list 
                                              WHERE order_list.product_id = product_list.product_id 
                                              GROUP BY order_list.product_id 
                                              ORDER BY SUM(order_list.order_qty) 
                                              DESC");
      $pastriesModal = mysqli_query($conn, "SELECT *,order_list.product_id, product_list.product_name AS final, product_list.product_price AS price, SUM(order_list.order_qty) AS 
      totalQuantity FROM order_list, product_list 
        WHERE order_list.product_id = product_list.product_id 
        GROUP BY order_list.product_id 
        ORDER BY SUM(order_list.order_qty) 
        DESC");                                        
    }else if($sorting == "latest"){
      $sort = "Latest products";
      $add = " ORDER BY product_id DESC";
      $pastries = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
      $pastriesModal = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1".$add);
    }
    ?>
    <div class="container">
    <div class="dropdown">
<button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><?=$sort?></button>
<ul class="dropdown-menu">
  <li><a href = "menu.php?sort=desc"class="dropdown-item">Lowest price</a></li>
  <li><a href = "menu.php?sort=asc"class="dropdown-item">Highest price</a></li>
  <li><a href = "menu.php?sort=best"class="dropdown-item">Best sellers</a></li>
  <li><a href = "menu.php?sort=latest"class="dropdown-item">Latest products</a></li>
</ul>
</div>
  <div class="card-deck">
    <?php
    while($pastriesRS = mysqli_fetch_assoc($pastries)):
    ?>
    <div class="col-12 col-lg-3 col-md-6">
      <div class="card mb-5">
      <img class="card-img-top" src="<?=$pastriesRS['prod_imgpath']?>" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title"><?=$pastriesRS['product_name'].'&nbsp'.$pastriesRS['product_price']?>&#8369;</h5>
          <p class="card-text"><?=$pastriesRS['product_desc']?></p>
          <a href="#exampleModal<?php $_SESSION['product_id'] = $pastriesRS['product_id']; echo $pastriesRS['product_id']?>" data-toggle="modal" data-target="#exampleModal<?=$pastriesRS['product_id']?>" class="btn btn-primary">Go to</a>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</div>


<?php
  $who = mysqli_query($conn, "SELECT * FROM register");
  $whoRS = mysqli_fetch_assoc($who);
  $person = $_SESSION['name'] = $whoRS['reg_name'];
?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">User Information</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Welcome to RACS! <?=$_SESSION['name1']?>
        <br>Would you like to change your information?<br>
        <div class ="center">
        <form action="changeinfo.php" method="post">
          <label for="changeEmail"><b>Your name:</b></label><br>
          <input type="text" name="changeName" value="<?=$_SESSION['name1']?>" required><br>
          <label for="changeEmail"><b>Your Email:</b></label><br>
          <input type="email" name="changeEmail" value="<?= $_SESSION["email1"]?>" required><br>
          <label for="changeEmail"><b>Your Password:</b></label><br>
          <input type="text" name="changePassword" value="<?= $_SESSION["pwd1"]?>" required><br>
          </div>
          <br>
          <table style = "width: 100%; border: 1px solid black" class = "center">
            <tr>
              
              <th>Name</th>
              <th>Order</th>
              <th>Quantity</th>
              <th>Status</th>
              <th>Cancel</th>
            </tr>
            <tr>
              <?php
                $infoTable = mysqli_query($conn, "SELECT orders.order_id AS id, orders.reg_name AS name, 
                                          product_list.product_name AS product, order_list.order_qty AS qty, 
                                          orders.order_status AS status, order_list.ordlist_date AS date 
                                          FROM orders, product_list, order_list 
                                          WHERE order_list.order_id = orders.order_id 
                                          AND order_list.product_id = product_list.product_id 
                                          AND orders.reg_name ='".$_SESSION['name1']."' 
                                          AND orders.reg_email = '".$_SESSION['email1']."'");
                while($infoTableRS=mysqli_fetch_assoc($infoTable)):
                  if($infoTableRS['status'] == 0){
                    $status = "pending";                
                  }else{
                    $status = "complete";
                  }
              ?>
             
              <td><?=$infoTableRS['name']?></td>
              <td><?=$infoTableRS['product']?></td>
              <td><?=$infoTableRS['qty']?></td>
              <td><?=$status?></td>
              <td style ="text-align: center;"><a href="cancelOrder.php?id=<?=$infoTableRS['id']?>">&times;</a></td>              
            </tr>
            <?php endwhile; ?>
          </table>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" value="Save changes" class="btn btn-primary">
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
      <?php
        while($pastriesModalRS = mysqli_fetch_assoc($pastriesModal)):
      ?>
<div class="modal fade" id="exampleModal<?=$pastriesModalRS['product_id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModal2Label" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModal2Label"><?=$pastriesModalRS['product_name']?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    

        
        
          <div>
          <img src="<?=$pastriesModalRS['prod_imgpath']?>" alt="" style="height:20em;" class="img-responsive center-block d-block mx-auto"/>
          </div>
          <br>
          <div><?=$pastriesModalRS['product_desc']?></div><br>
          <p>Please put your order requests here. Leave blank if none</p>
          <form action="ordering.php?id=<?=$pastriesModalRS['product_id']?>&cid=<?=$pastriesModalRS['category_id']?>" method="post">
          <textarea class="form-control" name="textarea" id="exampleFormControlTextarea1" rows="3"></textarea>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary mr-auto" data-dismiss="modal">Close</button>
        
          <input type="number" name="qty" id="inputPassword2" placeholder="QTY" min="1" value=1>
        <input type="submit" value="Order"class="btn btn-primary mb-1"></input>
      </form>
      </div>
    </div>
  </div>
</div>
<?php endwhile; ?>
</body>
</html>