<?php
    require '../../includes/db.php';
    session_start();
    if(isset($_POST['changeName'])){
        $newName=$_POST['changeName'];
    }else{
        $newName = $_SESSION["name1"];
    }
    if(isset($_POST['changeEmail'])){
        $newEmail=$_POST['changeEmail'];
    }else{
        $newEmail = $_SESSION["email1"];
    }
    if(isset($_POST['changePassword'])){
        $newPass=$_POST['changePassword'];
    }else{
        $newPass = $_SESSION["pwd1"];
    }
    $sql = mysqli_query($conn, "UPDATE register SET reg_name ='$newName',reg_email='$newEmail',reg_password='$newPass' WHERE reg_id =".$_SESSION['id1']."");
    header("Location: menu.php");
?>