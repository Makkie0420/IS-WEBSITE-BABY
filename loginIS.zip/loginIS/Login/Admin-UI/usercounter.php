<?php
  require '../../includes/db.php';
  //COUNTER FOR ONLINE PEEPS
  $onlineCustomer = mysqli_query($conn, "SELECT SUM(reg_status) AS totalOnline FROM register WHERE user_type = 3");
  $onlineAdmin = mysqli_query($conn, "SELECT SUM(reg_status) AS totalOnline FROM register WHERE user_type = 1");
  $counter1 = mysqli_fetch_assoc($onlineCustomer);
  $counter2 = mysqli_fetch_assoc($onlineAdmin);
  $sum1 = $counter1['totalOnline'];
  $sum2 = $counter2['totalOnline'];
  //COLOR CORRECTOR FOR ADMIN LOGINS
  if ($counter2['totalOnline'] > 0){
    $sum2 = "<span style = 'color: green'>".$counter2['totalOnline']."</span>";
  }else{
    $sum2 = "<span style = 'color: red'>".$counter2['totalOnline']."</span>";
  }
  //COLOR CORRECTOR FOR CUSTOMER LOGINS
  if ($counter1['totalOnline'] > 0){
    $sum1 = "<span style = 'color: green'>".$counter1['totalOnline']."</span>";
  }else{
    $sum1 = "<span style = 'color: red'>".$counter1['totalOnline']."</span>";
  }
  echo "<p>Total Admin: ".$sum2."&nbsp&nbsp|&nbsp&nbspTotal Customers: ".$sum1."&nbsp&nbsp|</p>";
?>
