<?php
  require '../../includes/db.php';
  session_start();
  $dateMode = "Overall";
  $ordAddition = "";
  $ordersTotal = "";
  $salesAddition = "";
  $profitAddition = "";
  $dateAddition = "";
  if(isset($_GET['mode'])){
    $dateMode = $_GET['mode'];
  }
  if(isset($_GET['date'])){
    $mode = $_GET['date'];
    if($mode == 1){
      $ordAddition = " WHERE DATEDIFF(ordlist_date, CURRENT_DATE) BETWEEN -1 AND 0";
      $salesAddition = " AND DATEDIFF(order_list.ordlist_date, CURRENT_DATE) BETWEEN -1 AND 0";
      $profitAddition = " AND DATEDIFF(order_list.ordlist_date, CURRENT_DATE) BETWEEN -1 AND 0";
      $dateAddition = " WHERE DATEDIFF(ordlist_date, CURRENT_DATE) BETWEEN -1 AND 0";
      }else if ($mode == 2){
        $ordAddition = " WHERE DATEDIFF(ordlist_date, CURRENT_DATE) BETWEEN -7 AND 0";
        $salesAddition = " AND DATEDIFF(order_list.ordlist_date, CURRENT_DATE) BETWEEN -7 AND 0";
        $profitAddition = " AND DATEDIFF(order_list.ordlist_date, CURRENT_DATE) BETWEEN -7 AND 0";
        $dateAddition = " WHERE DATEDIFF(ordlist_date, CURRENT_DATE) BETWEEN -7 AND 0";
      }else if ($mode == 3){
        $ordAddition = " WHERE DATEDIFF(ordlist_date, CURRENT_DATE) BETWEEN -31 AND 0";
        $salesAddition = " AND DATEDIFF(order_list.ordlist_date, CURRENT_DATE) BETWEEN -31 AND 0";
        $profitAddition = " AND DATEDIFF(order_list.ordlist_date, CURRENT_DATE) BETWEEN -31 AND 0";
        $dateAddition = " WHERE DATEDIFF(ordlist_date, CURRENT_DATE) BETWEEN -31 AND 0";
      }
   }
   function checker(){
    $up = "";
    $down = "";
    if($ordersTotal > 0){
    }
   }
  //SYSTEM NAME
  $sys = mysqli_query($conn, "SELECT * FROM system_settings");
  $companySys = mysqli_fetch_assoc($sys);
  //COUNTER FOR ONLINE PEEPS
  $online = mysqli_query($conn, "SELECT SUM(reg_status) AS totalOnline FROM register");
  $counter = mysqli_fetch_assoc($online);
  $sum = $counter['totalOnline'];
  //TOTAL ORDERS SQL
  $sqlTotalOrders = mysqli_query($conn, "SELECT SUM(order_qty) AS totalOrder FROM order_list".$ordAddition);
  $totalOrders = mysqli_fetch_assoc($sqlTotalOrders);
  $ordersTotal = $totalOrders['totalOrder'];
  //TOTAL SALES SQL
  $sqlTotalSales = mysqli_query($conn, "SELECT SUM(product_list.product_price * order_list.order_qty) AS totalSales 
                                        FROM order_list, product_list 
                                        WHERE order_list.product_id = product_list.product_id".$salesAddition);
  $totalSales = mysqli_fetch_assoc($sqlTotalSales);
  $salesTotal = $totalSales['totalSales'];
  //TOTAL PROFIT SQL
  $sqlTotalProfit = mysqli_query($conn, "SELECT SUM(product_list.product_price * order_list.order_qty) - SUM(product_list.product_cost*order_list.order_qty) AS totalProfit 
                                          FROM order_list, product_list 
                                          WHERE order_list.product_id = product_list.product_id".$profitAddition);
  $totalProfit = mysqli_fetch_assoc($sqlTotalProfit);
  $profitTotal = round($totalProfit['totalProfit'], 2);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> ADMIN DASHBOARD </title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src = "http://code.jquery.com/jquery-latest.js"></script>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
     <script>
          $(document).ready(function () {
            setInterval(function() {
          $.get("usercounter.php", function (result) {
            $('#test').html(result);
          });
          }, 1000);
      });
     </script>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Dashboard</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="#" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
          <li>
            <a href="controls.php" class="inactive">
              <i class='bx bx-grid-alt' ></i>
              <span class="links_name">System controls</span>
            </a>
        </li>
        <li>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard"><?=$dateMode?></span>
      </div>
      <div class="profile-details">
        





        <div id = "test"></div>






        <a href = '../index.php'><span class="admin_name"><?=$companySys['sys_name']?></span></a>
      </div>
    </nav>
    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <?php
            //------------------------------------------------------------------------------MODAL FOR TOTAL ORDERS
            $modalPastyOrders = mysqli_query($conn, "SELECT order_list.ordlist_date as orderDate FROM order_list WHERE order_list.category_id = 1".$salesAddition); 
            $modalCakeOrders = mysqli_query($conn, "SELECT order_list.ordlist_date as orderDate FROM order_list WHERE order_list.category_id = 2".$salesAddition);
            $modalCustomers = mysqli_query($conn, "SELECT orders.reg_name as customers FROM orders, order_list WHERE order_list.order_id = orders.order_id".$salesAddition);
            ?>
          <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal"><div class="box-topic">Total Orders</div></a>
          <div class="modal" id="myModal" >
          <div class="modal-dialog modal-lg" style="width:90%">
              <div class="modal-content">
                  <div class="modal-header">
                      <h4 class="modal-title">Total Orders</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                  </div>
                  <div class="modal-body">
                    <h4 style="text-align:center">Pastry Orders</h4>
                    <div class = "modalboxes1">
                    <ul class="details" style = "display: inline-block; list-style-type: none; padding-left: 20px">
                    <li class="topic" style = "display: inline-block; list-style-type: none">Date</li>
                    <?php
                    //SQL FOR DATE COLUMN
                      $modalDate = mysqli_query($conn, "SELECT ordlist_date AS orderdate FROM order_list WHERE category_id = 1".$salesAddition);                     
                      while($dateModal = mysqli_fetch_assoc($modalDate)):
                        $time = strtotime($dateModal['orderdate']);
                      ?>
                      <li><a href="#"><?=date("M d, Y h:i:sa", $time)?></a></li>
                      <?php 
                      endwhile;
                    ?>
                  </ul>
                  <ul class="details" style = "display: inline-block; list-style-type: none; padding-left: 20px">
                    <li class="topic" style = "display: inline-block; list-style-type: none">Customer</li>
                    <?php
                    //SQL FOR CUSTOMER COLUMN
                      $modalCustomers = mysqli_query($conn, "SELECT orders.reg_name AS orderNames 
                                                FROM order_list, orders 
                                                WHERE order_list.order_id = orders.order_id AND order_list.category_id = 1".$salesAddition);                     
                      while($customersModal = mysqli_fetch_assoc($modalCustomers)):
                      ?>
                      <li><a href="#"><?=$customersModal['orderNames']?></a></li>
                      <?php 
                      endwhile;
                    ?>
                  </ul>
                  <ul class="details" style = "display: inline-block; list-style-type: none; padding-left: 20px">
                    <li class="topic" style = "display: inline-block; list-style-type: none">Product</li>
                    <?php
                    //SQL FOR PRODUCT COLUMN
                      $modalCustomers = mysqli_query($conn, "SELECT product_list.product_name AS productnames 
                                                            FROM product_list, order_list 
                                                            WHERE order_list.product_id = product_list.product_id AND order_list.category_id = 1".$salesAddition);                     
                      while($customersModal = mysqli_fetch_assoc($modalCustomers)):
                      ?>
                      <li><a href="#"><?=$customersModal['productnames']?></a></li>
                      <?php 
                      endwhile;
                    ?>
                  </ul>
                  <ul class="details" style = "display: inline-block; list-style-type: none; padding-left: 20px">
                    <li class="topic" style = "display: inline-block; list-style-type: none">Quantity</li>
                    <?php
                    //SQL FOR QTY COLUMN
                      $modalCustomers = mysqli_query($conn, "SELECT order_qty FROM order_list WHERE category_id = 1".$salesAddition);                     
                      while($customersModal = mysqli_fetch_assoc($modalCustomers)):
                      ?>
                      <?php
                      if($customersModal['order_qty'] > 1){
                        $qty = '&nbsporders';
                      }else{
                        $qty = '&nbsporder';
                      }
                      ?>
                      <li><a href="#"><?=$customersModal['order_qty']?><?php echo $qty?></a></li>
                      <?php 
                      endwhile;
                    ?>
                  </ul>
                  <h4 style="text-align:center">Cake Customizations</h4>
                    </div>
                    </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
              </div>
          </div>
        </div>
            <?php
            //------------------------------------------------------------------------------MODAL FOR TOTAL ORDERS
            ?>
            <div class="number"><?=$ordersTotal?></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class='bx bx-cart-alt cart'></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Sales</div>
            <div class="number"><?=$salesTotal?></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class='bx bxs-cart-add cart two' ></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Profit</div>
            <div class="number"><?=$profitTotal?></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text">Up from yesterday</span>
            </div>
          </div>
          <i class='bx bx-cart cart three' ></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Ingredients left</div>
            <div class="number">154</div>
            <div class="indicator">
              <i class='bx bx-down-arrow-alt down'></i>
              <span class="text">Down From Today</span>
            </div>
          </div>
          <i class='bx bxs-cart-download cart four' ></i>
        </div>
      </div>

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title">Recent Sales</div>
          <div class="sales-details">
            <ul class="details">
              <li class="topic">Date</li>
              <?php
              //SQL FOR DATE COLUMN
                $orderdate = mysqli_query($conn, "SELECT ordlist_date AS orderdate FROM order_list".$dateAddition);
                while($orderdateEXEC = mysqli_fetch_assoc($orderdate)):
                  $time = strtotime($orderdateEXEC['orderdate']);
                 ?>
                 <li><a href="#"><?=date("M d, Y h:i:sa", $time)?></a></li>
                 <?php 
                endwhile;
              ?>
            </ul>
            <ul class="details">
            <li class="topic">Customer</li>
              <?php
              //SQL FOR CUSTOMER COLUMN
                $ordlistID = mysqli_query($conn, "SELECT orders.reg_name AS ordernames 
                                          FROM order_list, orders 
                                          WHERE order_list.order_id = orders.order_id".$salesAddition);
                while($ordlistEXEC = mysqli_fetch_assoc($ordlistID)):
                 ?>
                 <li><a href="#"><?=$ordlistEXEC['ordernames']?></a></li>
                 <?php 
                endwhile;
              ?>
          </ul>
          <ul class="details">
            <li class="topic">Product</li>
            <?php
            //SQL FOR PRODUCT COLUMN
                $ordlistID = mysqli_query($conn, "SELECT order_list.product_id, order_list.product_id, product_list.product_name AS productnames
                FROM order_list, product_list 
                WHERE order_list.product_id = product_list.product_id".$salesAddition." 
                GROUP BY order_list.ordlist_id");
                while($ordlistEXEC = mysqli_fetch_assoc($ordlistID)):
                 ?>
                 <li><a href="#"><?=$ordlistEXEC['productnames']?></a></li>
                 <?php 
                endwhile;
              ?>
          </ul>
          <ul class="details">
            <li class="topic">Quantity</li>
            <?php
            //SQL FOR QTY COLUMN
                $ordlistID = mysqli_query($conn, "SELECT order_qty FROM order_list".$dateAddition);
                while($ordlistEXEC = mysqli_fetch_assoc($ordlistID)):
                 ?>
                 <li><a href="#"><?=$ordlistEXEC['order_qty']?></a></li>
                 <?php 
                endwhile;
              ?>
          </ul>
          <ul class="details">
            <li class="topic">Theme</li>
            <?php
            //SQL FOR THEME COLUMN
                $ordlistID = mysqli_query($conn, "SELECT ordlist_id, theme FROM order_list".$dateAddition);
                while($ordlistEXEC = mysqli_fetch_assoc($ordlistID)):
                 ?>
                 <li><a href="#exampleModal<?=$ordlistEXEC['ordlist_id']?>" data-target="#exampleModal<?=$ordlistEXEC['ordlist_id']?>" data-toggle="modal">Click here to expand</a></li>
                 <!-- Modal -->
                <div class="modal fade" id="exampleModal<?=$ordlistEXEC['ordlist_id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <b>Customizations and Request</b>
                        <h5 class="modal-title" id="exampleModalLabel"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <?php
                          if($ordlistEXEC['theme'] == ""){
                            echo "No requests";
                          }else{
                            ?>
                            <p style="word-wrap: break-word;"><?=$ordlistEXEC['theme']?></p>
                            <?php
                          }
                        ?>
                      </div>
                      <div class="modal-footer">
                      </div>
                    </div>
                  </div>
                </div>
                <?php endwhile; ?>
          </ul>
          </div>    
          <a href="?date=1&mode=Yesterday"><button id = "buttons">Yesterday</button></a>
          <a href="?date=2&mode=7 days"><button id = "buttons">Weekly</button></a>
          <a href="?date=3&mode=30 days"><button id = "buttons">Monthly</button></a>
          <a href="?mode=total"><button id = "buttons">Yearly</button></a>
        </div>
        
        <div class="top-sales box">
          <div class="title">Top Seling Products</div>
          <ul class="top-sales-details">           
            <?php
            //SQL FOR TOP SELLERS COLUMN
                $topSelling = mysqli_query($conn, "SELECT order_list.product_id, product_list.product_name AS final, product_list.product_price AS price, SUM(order_list.order_qty) AS
                                            totalQuantity FROM order_list, product_list
                                              WHERE order_list.product_id = product_list.product_id".$salesAddition."
                                              GROUP BY order_list.product_id
                                              ORDER BY SUM(order_list.order_qty)
                                              DESC;");
                while($topSellingEXEC = mysqli_fetch_assoc($topSelling)):
                 ?>
                 <li>
                 <a href="#">
              <span class="product"><?=$topSellingEXEC['final']?></span>
              </a>
            <span class="price"><?=$topSellingEXEC['price']?></span>
            <?php 
                endwhile;
              ?>
            </li>               
          </ul>
        </div>
      </div>
    </div>
  </section>
  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>
</body>
</html>
