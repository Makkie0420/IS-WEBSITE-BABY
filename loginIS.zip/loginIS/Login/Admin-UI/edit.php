<?php
require '../../includes/db.php';
session_start();
$pName = $_POST['productName'];
$pDesc = $_POST['productDesc'];
$pPrice = $_POST['productPrice'];
$pCost = $_POST['productCost'];
$pID = $_POST['productID'];
if ($_POST['edit'] == 'Update') {
    $sql = mysqli_query($conn, "UPDATE product_list SET product_name = '$pName', product_desc = '$pDesc', product_price = $pPrice, product_cost = $pCost WHERE product_id = $pID");
    ?>
    <script language="javascript">
        alert("Successfully edited!");
        location.href = "controls.php";
        </script>
<?php
} else if ($_POST['edit'] == 'Delete') {
    $sql = mysqli_query($conn, "DELETE FROM product_list WHERE product_id = $pID");
    ?>
    <script language="javascript">
        alert("Successfully deleted!");
        location.href = "controls.php";
        </script>
<?php
}
?>