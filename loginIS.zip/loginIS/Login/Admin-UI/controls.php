<?php
  require '../../includes/db.php';
  session_start();
  if(isset($_GET['name'])){
    $name = $_GET['name'];
  }else{
    $name = "";
  }
  if(isset($_GET['price'])){
    $price = $_GET['price'];
  }else{
    $price = "";
  }
  if(isset($_GET['id'])){
    $id = $_GET['id'];
  }else{
    $id = "";
  }
  if(isset($_GET['path'])){
    $path = $_GET['path'];
  }else{
    $path = "";
  }
  if(isset($_GET['desc'])){
    $desc = $_GET['desc'];
  }else{
    $desc = "";
  }
  if(isset($_GET['cost'])){
    $cost = $_GET['cost'];
  }else{
    $cost = "";
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> ADMIN DASHBOARD </title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src = "http://code.jquery.com/jquery-latest.js"></script>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
     <script>
          $(document).ready(function () {
            setInterval(function() {
          $.get("usercounter.php", function (result) {
            $('#test').html(result);
          });
          }, 1000);
      });
     </script>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Dashboard</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="index.php" class="inactive">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
          <li>
            <a href="#" class="active">
              <i class='bx bx-grid-alt' ></i>
              <span class="links_name">System controls</span>
            </a>
        </li>
        <li>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard"></span>
      </div>
      <div class="profile-details">
        <div id = "test"></div>
      </div>
    </nav>
    <div class="home-content">
        
    <div class="card bg-white black-content mx-auto" style="width: 70%">
  <div class="card-body">
    <div class="row">
      <div class="col-12 col-sm-6">
      <div class="card mx-auto" style="width: 18rem;">
        <img class="card-img-top" src="img/pholder.png" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Sample product Title + price</h5>
            <p class="card-text">Sample product descriptions</p>
            <a href="#" class="btn btn-primary">Go to</a>
        </div>
        </div>
        
      </div>
      <div class="col-12 col-sm-6">
        <h4>Inserting Station</h4>
        <form action="upload.php" method="post" enctype="multipart/form-data">
        <label for="formFile" class="form-label">Put your picture here</label><br>
        <input class="form-control" type="file" id="formFile" name="image" size="3"  accept="image/*" required>
        <label for="product">Put your product name here</label><br>
        <input type="text" name="productName"size="37" required><br>
        <label for="product">Put your product description here</label><br>
        <input type="text" name="productDesc"size="37" required><br>
        <label for="product">Put your product price here</label><br>
        <input type="number" name="productPrice"size="37" required><br>
        <label for="product">Put your product cost here</label><br>
        <input type="number" name="productCost"size="37" required>
        <br><br><input type="submit" value="Insert!" class="btn btn-primary">
        </form>
      </div>
    </div>  
  </div>    
</div>
</div>
<div class="card bg-white black-content mx-auto mt-4" style="width: 70%">
  <div class="card-body">
    <div class="row">
      <div class="col-12 col-sm-6">
      <div class="card mx-auto" style="width: 18rem;">
        <img class="card-img-top" src="../Customer-UI/<?=$path?>" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title"><?=$name?></h5>
            <p class="card-text"><?=$desc?></p>
            <a href="#" class="btn btn-primary">Go to</a>
        </div>
        </div>
        
      </div>
      <div class="col-12 col-sm-6">
        <h4>Editing Station</h4>
        <form action="edit.php" method="post">
        <br><label for="product">View product ID</label><br>
        <input type="text" name="productID"size="37" value="<?=$id?>" readonly><br>
        <label for="product">Put your product name here</label><br>
        <input type="text" name="productName"size="37" value="<?=$name?>" required><br>
        <label for="product">Put your product description here</label><br>
        <input type="text" name="productDesc"size="37" value="<?=$desc?>" required><br>
        <label for="product">Put your product price here</label><br>
        <input type="number" name="productPrice"size="37" value="<?=$price?>" required><br>
        <label for="product">Put your product cost here</label><br>
        <input type="number" name="productCost"size="37" value="<?=$cost?>" pattern="^\d*(\.\d{0,2})?$" required>
        <br><br><input type="submit" name = "edit" value="Update" class="btn btn-primary">
        <input type="submit" name = "edit" value="Delete" class="btn btn-primary ml-4">
        </form>
      </div>
    </div>  
  </div>    
</div>
</div>
<div class="card-deck mt-4">
    <?php
    $pastries = mysqli_query($conn, "SELECT * FROM product_list WHERE category_id = 1");
    while($pastriesRS = mysqli_fetch_assoc($pastries)):
    ?>
    <div class="col-12 col-lg-3 col-md-6">
      <div class="card mb-5">
      <img class="card-img-top" src="../Customer-UI/<?=$pastriesRS['prod_imgpath']?>" alt="Card image cap">
        <div class="card-body">
        <div class="row">
          <h5 class="card-title"><?=$pastriesRS['product_name'].'&nbsp'.$pastriesRS['product_price']?>&#8369;</h5>
          <p class="card-text"><?=$pastriesRS['product_desc']?></p>
          <a href="controls.php?name=<?=$pastriesRS['product_name']?>&price=<?=$pastriesRS['product_price']?>&id=<?=$pastriesRS['product_id']?>&desc=<?=$pastriesRS['product_desc']?>&path=<?=$pastriesRS['prod_imgpath']?>&cost=<?=$pastriesRS['product_cost']?>" class="btn btn-primary">Go to</a>
        </div>
      </div>
    </div>
    </div>
    <?php endwhile; ?>
        </div>
        </div>    
      </div>
    </div>
    </section>
                         
  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>
</body>
</html>