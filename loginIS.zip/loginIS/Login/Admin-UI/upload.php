<?php
 require '../../includes/db.php';
 session_start();
$image_file = $_FILES["image"];
$productName = $_POST['productName'];
$productDesc = $_POST['productDesc'];
$productPrice = $_POST['productPrice'];
$productCost = $_POST['productCost'];
if (!isset($image_file)) {
    die('No file uploaded.');
}
if (filesize($image_file["tmp_name"]) <= 0) {
    die('Uploaded file has no contents.');
}
$image_type = exif_imagetype($image_file["tmp_name"]);
if (!$image_type) {
    die('Uploaded file is not an image.');
}
$image_extension = image_type_to_extension($image_type, true);
$image_name = bin2hex(random_bytes(16)) . $image_extension;
move_uploaded_file(
    // Temp image location
    $image_file["tmp_name"],
    // New image location
    "../Customer-UI/img/" . $image_name 
);
$insert = mysqli_query($conn, "INSERT INTO product_list VALUES ('?', '1', '$productName', '$productDesc', '$productPrice', '$productCost', '?', 'img/".$image_name."', '1')");
?>
<script language="javascript">
        alert("Successfully added!");
        location.href = "controls.php";
        </script>