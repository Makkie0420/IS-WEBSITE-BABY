<?php
require '../includes/db.php';
session_start();
$update1 = mysqli_query($conn, "UPDATE register SET reg_status = 0 WHERE reg_id=".$_SESSION['id1'].";");
session_destroy();
unset($_SESSION["id1"]);
unset($_SESSION["name1"]);
header("Location:index.php");
?>