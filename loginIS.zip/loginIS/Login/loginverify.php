<?php
require '../includes/db.php';
session_start();
  $usernameemailPOST = $_POST["username_email"];
  $passwordPOST = $_POST["pwd"];
  $usernameemail = mysqli_real_escape_string($conn, $usernameemailPOST);
  $password = mysqli_real_escape_string($conn, $passwordPOST);
  $result = mysqli_query($conn, "SELECT * FROM register WHERE reg_name = '$usernameemail' OR reg_email = '$usernameemail'");

  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
    if($password == $row['reg_password']){
      if($row['user_type'] == 1){
        $_SESSION['id'] = $row['reg_id'];
        $_SESSION["name"] = $row['reg_email'];
        $_SESSION["login"] = true;
        if (isset($_SESSION['id'])){
            $update = mysqli_query($conn, "UPDATE register SET reg_status = 1 WHERE reg_id=".$_SESSION['id'].";");
            header("Location: Admin-UI/index.php?=admin");
        }
      }else{
        $_SESSION['id1'] = $row['reg_id'];
        $_SESSION["name1"] = $row['reg_name'];
        $_SESSION["email1"] = $row['reg_email'];
        $_SESSION["pwd1"] = $row['reg_password'];
        $_SESSION["login1"] = true;
        if (isset($_SESSION['id1'])){
            $update = mysqli_query($conn, "UPDATE register SET reg_status = 1 WHERE reg_id=".$_SESSION['id1'].";");
            header("Location: Customer-UI/about.php?=customer");
        }
      }
    }
    else{
        ?>  
        <script language="javascript">
        alert("Error: Password mismatch");
        location.href = "index.php";
        </script>
        <?php
    }
  }
  else{
    ?>  
        <script language="javascript">
        alert("Error: username not registered, please register");
        location.href = "index.php";
        </script>
        <?php
  }
?>