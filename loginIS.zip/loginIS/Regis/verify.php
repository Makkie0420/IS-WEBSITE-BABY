<?php
require '../includes/db.php';
if(!empty($_SESSION["id"])){
  header("Location:index.html");
}
  $namePOST = $_POST["name"];
  $emailPOST = $_POST["email"];
  $password = $_POST["pwd"];
  $confirmpassword = $_POST["c_pwd"];
  $name = mysqli_real_escape_string($conn, $namePOST);
  $email = mysqli_real_escape_string($conn, $emailPOST);
  $duplicate = mysqli_query($conn, "SELECT * FROM register WHERE reg_name = '$name' OR reg_email = '$email'");
  if(mysqli_num_rows($duplicate) > 0){
        ?>  
        <script language="javascript">
        alert("Email is already in use, please use a different one");
        location.href = "index.html";
        </script>
        <?php
  }
  else{
    if($password == $confirmpassword){
      $query = "INSERT INTO register VALUES('','$name','$email','$password','0','3',CURRENT_TIMESTAMP)";
      mysqli_query($conn, $query);
        ?>  
        <script language="javascript">
        alert("Successfully registered");
        location.href = "../Login/index.php";
        </script>
        <?php
    }
    else{
        ?>  
        <script language="javascript">
        alert("Password does not match!");
        location.href = "index.html";
        </script>
        <?php
    }
  }
?>